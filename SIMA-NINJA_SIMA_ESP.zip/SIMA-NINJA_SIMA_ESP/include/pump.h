#ifndef PUMP_H
#define PUMP_H

#include "motor_logic.h"


#define PUMP_PIN GPIO_NUM_4
#define START_POSITION 3000
#define HIGHEST_POSITION 3500

#define NORMAL_BAR_TOLERANCE 628
#define BLACK_BAR_TOLERANCE 400

extern uint32_t pump_motor_pos;
extern uint32_t pump_motor_gpos;

void setup_pump(void);
void prep_pump(void);
void pick_up_bar(void);
void pick_up_black_bar(void);
void release_bar(void);


#endif